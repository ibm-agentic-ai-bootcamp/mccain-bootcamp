Version 0.1.0
-------------

Base AI service LangGraph template, prepared using `ai-service-template <https://github.com/IBM/watson-machine-learning-samples/tree/master/cloud/ai-service-templates>`_ from `IBM/watson-machine-learning-samples` repository.