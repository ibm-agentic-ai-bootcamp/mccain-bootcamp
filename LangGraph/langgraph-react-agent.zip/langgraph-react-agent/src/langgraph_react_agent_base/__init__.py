#from .tools import dummy_web_search
from .get_traffic_incidents import get_traffic_incidents

# TOOLS = [dummy_web_search, get_traffic_incidents]
TOOLS = [get_traffic_incidents]
