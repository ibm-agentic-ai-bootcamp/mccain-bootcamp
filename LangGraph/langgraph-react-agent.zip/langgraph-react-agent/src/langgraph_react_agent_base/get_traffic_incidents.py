import requests
from langchain_core.tools import tool


@tool("get_traffic", parse_docstring=True)
def get_traffic_incidents(longitude:str, latitude:str) -> dict[str, list]:
    """
    Retrieve a list of traffic indicents for a given location and return it as a dictionary.

    Args:
        longitude: The longitude of the location for which traffic information is retrieved.
        latitude: The latitude of the location for which traffic information is retrieved.
    
    Returns: 
        A dictionary that has a key named "incidents", whose value is a list of individual incidents.
    """
    json_data = {}
    param_in = f"circle:{latitude},{longitude};r=10000"
    param_locationReferencing = "none"

    api_key = "5LKs1vJzQqVVHBcJIWyNlg7yBqJNDBcBAn--YYBbC04"
    api_url = "https://data.traffic.hereapi.com/v7/incidents"
#    api_key = connections.key_value(CONNECTION_HERE_APIKEY)['apikey']
#    api_url = connections.key_value(CONNECTION_HERE_URL)['url']
            
    # Construct the query parameters
    params = {
            "in": param_in,
            "locationReferencing": param_locationReferencing,
            "apiKey": api_key
    }

    try:
            # Send GET request with parameters
            response = requests.get(api_url, params=params, headers={"Accept": "application/json"})

            # Check if the request was successful
            if response.status_code == 200:
                json_data =  response.json()  # Return JSON response
            else:
                return {"error": f"Request failed with status {response.status_code}", "details": response.text}

    except requests.RequestException as e:
            return {"error": "Request exception occurred", "details": str(e)}

    structured_data = {"incidents": []}

        # Check if "results" exist in the JSON
    if "results" in json_data:
            for result in json_data["results"]:
                # Extract description if it exists
                if "incidentDetails" in result and "description" in result["incidentDetails"]:
                    structured_data["incidents"].append(result["incidentDetails"]["description"]["value"])

    return structured_data